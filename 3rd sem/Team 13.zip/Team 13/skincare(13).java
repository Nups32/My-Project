import java.util.Scanner;

class Underage extends Exception {
    public Underage(String str) {
        super(str);
    }
}

class Test {
    static void check(int age) throws Underage {
        if (age < 18) {
            throw new Underage("You are a bit underage, you need a different skincare routine!!");
        } else {
            System.out.println("Eligible for given skincare routine!!");
        }
    }
}

class Skincare {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Hello user! Welcome to the Skincare Routine Generator!");
        System.out.println("Please answer the following questions:");
        System.out.println("What is your name?");
        String name = scanner.nextLine();
        System.out.println("What is your age?");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        System.out.println("1. What is your skin type? (oily, dry, normal, combination)");
        String skinType = scanner.nextLine();
        System.out.println("2. What is your main skin concern? (acne, aging, dryness, sensitivity)");
        String skinConcern = scanner.nextLine();
        System.out.println("-------------------------------------------------------------------");
        System.out.println("So,"+""+name+" Based on your answers, your skincare routine is:");
		System.out.println("Loading...it may take a while...");

        // Pause after the introduction
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (skinType.equals("oily")) {
            System.out.println("- Cleanser: Oil-free foaming cleanser");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Toner: Mattifying toner");
        } else if (skinType.equals("dry")) {
            System.out.println("- Cleanser: Gentle cream cleanser");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Toner: Hydrating toner");
        } else if (skinType.equals("normal")) {
            System.out.println("- Cleanser: Balancing gel cleanser");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Toner: Refreshing toner");
        } else if (skinType.equals("combination")) {
            System.out.println("- Cleanser: Purifying gel cleanser");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Toner: Balancing toner");
        }

        // Pause after the skincare routine
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (skinConcern.equals("acne")) {
            System.out.println("- Treatment: Salicylic acid spot treatment");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Moisturizer: Oil-free moisturizer");
        } else if (skinConcern.equals("aging")) {
            System.out.println("- Treatment: Retinol serum");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Moisturizer: Anti-aging cream");
        } else if (skinConcern.equals("dryness")) {
            System.out.println("- Treatment: Hyaluronic acid serum");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Moisturizer: Rich moisturizing cream");
        } else if (skinConcern.equals("sensitivity")) {
            System.out.println("- Treatment: Calming serum");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("- Moisturizer: Gentle moisturizer");
        }

        // Pause at the end
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Remember to always use sunscreen during the day!");
        System.out.println("Thank you for using our skincare routine generator!! Visit again!");
        System.out.println("-------------------------------------------------------------------");

        try {
            Test o = new Test();
            o.check(age);
            // Pause after the eligibility check
            Thread.sleep(2000);
            System.out.println("Skin care routine over");
        } catch (Underage e) {
            System.out.println("Invalid age! " + e.getMessage());
        } catch (InterruptedException e) {
            System.out.println("Thread sleep interrupted");
        }
        finally{
            System.out.println("thank you !")
        }
    }
}
