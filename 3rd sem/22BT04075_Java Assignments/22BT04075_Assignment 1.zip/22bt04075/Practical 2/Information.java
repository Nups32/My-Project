class Information
{
	public static void main(String args[])
	{
		System.out.println("My name is Nupur");
		System.out.println("Enrollment no. :- 22BT04075");
		System.out.println("Favorite Computer Langauge is c++");
		System.out.println("Course :- B.tech CSE");
		System.out.println("CGPA :- 8.08");
	
	
	
	}


}