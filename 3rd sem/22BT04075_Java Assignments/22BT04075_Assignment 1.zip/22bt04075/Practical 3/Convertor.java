class Convertor
{
	public static void main(String aa[])
	{
		double ruppees=100;
		double dollar=ruppees/80;
		
		System.out.println("Dollar = " +dollar);
	}


}

