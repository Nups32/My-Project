class fibbfac
{
	static int fact(int n)
	{
		if(n<=1)
		{
			return 1;
		}
		else
		{
			return n*fact(n-1);
		}
	}
	static int fib(int n)
	{
		if(n<=0)
		{
			return 0;
		}
		else if(n==1)
		{
			return 1;
		}
		else
		{
			return fib(n-1)+fib(n-2);
		}
	}
	public static void main(String arg[])
	{
		int num=5;
		System.out.println("Factorial = "+fact(num));
		System.out.println("Fibonnaci :");
		for (int i = 0; i < num; i++) 
		{
            System.out.print(fib(i) + " ");
        }
	}
}