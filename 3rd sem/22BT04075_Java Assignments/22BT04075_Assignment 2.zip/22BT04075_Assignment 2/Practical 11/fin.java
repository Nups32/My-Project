class fin
{
    public static void main(String args[])
    {
        final int a=1;
        int b=2;
        a=a+b;
        System.out.println("The addition is:"+a);
    }
}


