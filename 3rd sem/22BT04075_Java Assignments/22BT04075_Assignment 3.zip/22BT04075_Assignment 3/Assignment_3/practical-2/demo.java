package MyPack;

class A{
	//default
		String str = "HELLO A";
}
class B{
	/*private*/ String str = "HELLO B";
}
 class C{
	protected String str = "HELLO C";
}
class D{
	public String str = "HELLO C";
}




