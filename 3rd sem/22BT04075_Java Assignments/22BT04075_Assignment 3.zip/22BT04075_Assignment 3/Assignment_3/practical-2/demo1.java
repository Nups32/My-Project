package MyPackage2;
import MyPack.PackDemo;
class E{
	public static void main(String args[]){
		PackDemo obj =new PackDemo();
		obj.view();
	}
}

